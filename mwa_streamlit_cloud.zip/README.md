
# MWA Points Tracker — Streamlit Cloud (Google Sign-In + Per-User Google Drive)

## One-time setup (Streamlit Cloud)
1. Create a **Google Cloud** project and OAuth2 credentials (**Web application**):
   - Authorized redirect URI: your deployed Streamlit URL (no trailing slash), e.g.  
     `https://your-app-name.streamlit.app`
2. Enable APIs:
   - **Google Drive API**
   - **Google Sheets API**
3. In **Streamlit Cloud → App → Settings → Secrets**, add:
```
[oauth]
client_id = "YOUR_GOOGLE_CLIENT_ID"
client_secret = "YOUR_GOOGLE_CLIENT_SECRET"
redirect_uri = "https://your-app-name.streamlit.app"
```
4. Deploy this app (`streamlit run app.py`).

## How it works
- Users log in with **Google** (OAuth).
- The app creates/opens a spreadsheet named **"MWA Points Data"** in the user's **own Google Drive**.
- Data is written to sheets:
  - `Entries` (all your intervals)
  - `Holidays` (YYYY-MM-DD list)

## Notes
- The app requests **drive.file** scope, so it can only create/read files it created.
- Each user’s data stays in their Google Drive — no centralized database needed.
